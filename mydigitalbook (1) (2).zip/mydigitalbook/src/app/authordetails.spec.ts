import { Authordetails } from './authordetails';

describe('Authordetails', () => {
  it('should create an instance', () => {
    expect(new Authordetails()).toBeTruthy();
  });
});
