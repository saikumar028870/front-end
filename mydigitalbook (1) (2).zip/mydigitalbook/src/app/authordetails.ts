export class Authordetails {

    emailId!: string;
	username!: string;
	password! : string ;
	
}
