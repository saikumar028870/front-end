export class Createbook {
    bookId!: number;
	 authorName!: string;
     authorId!: number;
     bookName!:String;
     price!:DoubleRange;
     publisher!:string
     publishedDate !:string;
     category!:string;
     active! :boolean
     
}
