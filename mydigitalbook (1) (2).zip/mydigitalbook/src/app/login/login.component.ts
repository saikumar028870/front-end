import { Component, OnInit } from '@angular/core';
import { Authordetails } from '../authordetails';
import { AuthorserviceService } from '../authorservice.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  author:Authordetails=new Authordetails();
  constructor(private adminService : AuthorserviceService) { }

  ngOnInit(): void {
  }
  authorLogin(){
    console.log(this.author); 
    
    
   this.adminService.authorLogin(this.author).subscribe(
    data=>{
      alert("Login success")
  },
  error=>alert("Login failure")
  )
  }

}
