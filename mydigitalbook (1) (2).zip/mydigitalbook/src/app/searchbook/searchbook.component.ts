import { Component, OnInit } from '@angular/core';
import { BookserviceService } from '../bookservice.service';
import { Createbook } from '../createbook';

@Component({
  selector: 'app-searchbook',
  templateUrl: './searchbook.component.html',
  styleUrls: ['./searchbook.component.scss']
})
export class SearchbookComponent implements OnInit {
  book:Createbook=new Createbook();
  constructor(private bookService : BookserviceService) { }


  ngOnInit(): void {
  }
  getBooks(category:string, price:string,authorName:string,publisher:string)
  {
    console.log(this.book); 
    
    
    this.bookService.getBooks(this.category,this.).subscribe({
     next: (res:any)=>{
       console.log("Book created successfully" ,res);
       },
   error: (err:any)=>{
     console.log(err);
    
 }
   })
   
  }

 
}
